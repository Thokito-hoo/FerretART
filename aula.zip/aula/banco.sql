create database atividade;
use atividade;

create table usuarios (
    id_usuario int auto_increment primary key,
    nome varchar(50) not null,
    email varchar(50) unique not null,
    cpf varchar(11) unique not null,
    senha varchar(50) not null
);

select * from usuarios;