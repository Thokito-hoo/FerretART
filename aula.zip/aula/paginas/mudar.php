<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modificar</title>
</head>

<body>
    <h1>Modificar Usuário</h1>

    <form method="POST">
        <label>Digite seu email:</label>
        <input type="email" name="email" placeholder="seu@email.com"> <br><br>

        <button type="submit" name="procurar">Procurar</button>

    </form>


<?php

$conn = new mysqli("localhost", "root", "", "atividade");


if (isset($_POST["procurar"])) {

    $email = $_POST["email"];

    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultado = $conn->query($sql);
    $usuario = $resultado->fetch_assoc();

    if ($usuario) {
        echo "ID: " . $usuario["id_usuario"] . "<br>";
        echo "Nome: " . $usuario["nome"] . "<br>";
        echo "Email: " . $usuario["email"] . "<br>";
        echo "CPF: " . $usuario["cpf"] . "<br>";
        echo "Senha: " . $usuario["senha"] . "<br>";
    } else {
        echo "Usuário não encontrado.";
    }

    $resultado = $conn->query($sql);

    $usuario = $resultado->fetch_assoc();


    if ($usuario) {

        ?>

        <h2>Editar usuário</h2>

        <form method="POST">

            <input type="hidden" name="email_antigo" value="<?php echo $usuario["email"]; ?>">

            <label>Nome:</label>
            <input type="text" name="nome" value="<?php echo $usuario["nome"]; ?>"> <br><br>
            <label>CPF:</label>
            <input type="text" name="cpf" value="<?php echo $usuario["cpf"]; ?>"> <br><br>
            <label>Senha:</label>
            <input type="password" name="senha" value="<?php echo $usuario["senha"]; ?>"> <br><br>

            <button type="submit" name="alterar">Alterar</button>

        </form>

        <?php
    } else {
        echo "Usuário não encontrado.";
    }
}

if (isset($_POST["alterar"])) {

    $email_antigo = $_POST["email_antigo"];
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];

    $sql = "UPDATE usuarios
            SET nome = '$nome', cpf = '$cpf', senha = '$senha'
            WHERE email = '$email_antigo'";

    $conn->query($sql);

    echo "Usuário alterado com sucesso!";
}
?>

</body>
</html>