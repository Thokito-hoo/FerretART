<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Apagar</title>
</head>

<body>
    <h1>Apagar Usuário</h1>
    <form method="POST">
        <label>Digite seu email:</label>
        <input type="email" name="email" placeholder="seu@email.com"> <br><br>

        <button type="submit" name="procurar">Procurar</button> <br><br>
    </form>

<?php
$conn = new mysqli("localhost", "root", "", "atividade");

if (isset($_POST["procurar"])) {

    $email = $_POST["email"];

    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultado = $conn->query($sql);
    $usuario = $resultado->fetch_assoc();

    if ($usuario) {

        echo "ID: " . $usuario["id_usuario"] . "<br>";
        echo "Nome: " . $usuario["nome"] . "<br>";
        echo "Email: " . $usuario["email"] . "<br>";
        echo "CPF: " . $usuario["cpf"] . "<br>";
        echo "Senha: " . $usuario["senha"] . "<br>";
        ?>

        <h2>Apagar usuário</h2>
        <p>
            Ao deletar o usuário não será possível recuperá-lo.
            Tem certeza que deseja apagar?
        </p>

        <form method="POST">
            <input type="hidden" name="email" value="<?php echo $usuario["email"]; ?>">
            <button type="submit" name="apagar">Apagar</button>
        </form>

        <?php
    } else {
        echo "Usuário não encontrado.";
    }
}

if (isset($_POST["apagar"])) {

    $email = $_POST["email"];
    $sql = "DELETE FROM usuarios WHERE email = '$email'";
    $conn->query($sql);
    echo "Usuário apagado com sucesso!";
}
?>

</body>
</html>