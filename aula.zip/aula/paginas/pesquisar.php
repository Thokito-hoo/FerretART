<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pesquisar</title>
</head>

<body>

    <h1>Pesquisar Usuário</h1>

    <form method="POST">
        <label>Digite seu email:</label>
        <input type="email" name="email" placeholder="seu@email.com"> <br><br>

        <button type="submit">Pesquisar</button>
    </form>

<?php
$conn = new mysqli("localhost", "root", "", "atividade");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];

    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultado = $conn->query($sql);
    $usuario = $resultado->fetch_assoc();

    if ($usuario) {
        echo "ID: " . $usuario["id_usuario"] . "<br>";
        echo "Nome: " . $usuario["nome"] . "<br>";
        echo "Email: " . $usuario["email"] . "<br>";
        echo "CPF: " . $usuario["cpf"] . "<br>";
        echo "Senha: " . $usuario["senha"] . "<br>";
    } else {
        echo "Usuário não encontrado.";
    }
}
?>

</body>
</html>