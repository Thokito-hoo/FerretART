<?php

$conn = new mysqli("localhost", "root", "", "atividade");

$nome = $_POST["nome"];
$email = $_POST["email"];
$cpf = $_POST["cpf"];
$senha = $_POST["senha"];

$sql = "INSERT INTO usuarios (nome, email, cpf, senha)
        VALUES ('$nome', '$email', '$cpf', '$senha')";

$conn->query($sql);

echo "Cadastro efetuado com sucesso"

?>